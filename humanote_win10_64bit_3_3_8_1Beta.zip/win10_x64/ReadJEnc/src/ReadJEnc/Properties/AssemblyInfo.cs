﻿using System.Reflection;
//using System.Runtime.CompilerServices;
//using System.Runtime.InteropServices;

// アセンブリに関する一般情報は以下の属性セットをとおして制御されます。 
// アセンブリに関連付けられている情報を変更するには、
// これらの属性値を変更してください。
[assembly: AssemblyTitle("ReadJEnc 文字コード自動判別ライブラリ")]
//[assembly: AssemblyDescription("")]
//[assembly: AssemblyConfiguration("")]
//[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("ReadJEnc")]
[assembly: AssemblyCopyright("(C) 2014 hnx8(H.Takahashi)")]
//[assembly: AssemblyTrademark("")]
//[assembly: AssemblyCulture("")]

// ComVisible を false に設定すると、その型はこのアセンブリ内で COM コンポーネントから 
// 参照不可能になります。COM からこのアセンブリ内の型にアクセスする場合は、 
// その型の ComVisible 属性を true に設定してください。
//[assembly: ComVisible(false)]

// 次の GUID は、このプロジェクトが COM に公開される場合の、typelib の ID です
//[assembly: Guid("76f8dda2-b6ca-4e49-8832-dd19c8f164c8")]

// アセンブリのバージョン情報は、以下の 4 つの値で構成されています:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.2.1.1206")]
//[assembly: AssemblyFileVersion("1.0.0.0")]
